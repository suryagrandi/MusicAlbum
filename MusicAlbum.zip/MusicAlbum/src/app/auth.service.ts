import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  url: any = `${environment.host_url}`
  constructor(private http: HttpClient) {

  }

   GetAllMusic() {
   
    return this.http.get(this.url +'/Music/GetAll')
  }
   GetAllAlbums() {
   
    return this.http.get(this.url +'/Album/GetAll')
  }
   AddAlbums(c){
  
    return this.http.post(this.url +'/Album/Create',c);
  }
    
}



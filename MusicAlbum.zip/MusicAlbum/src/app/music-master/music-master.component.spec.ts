import { ComponentFixture, TestBed } from '@angular/core/testing';

import { MusicMasterComponent } from './music-master.component';

describe('MusicMasterComponent', () => {
  let component: MusicMasterComponent;
  let fixture: ComponentFixture<MusicMasterComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ MusicMasterComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(MusicMasterComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});

import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '../auth.service';

@Component({
  selector: 'app-music-master',
  templateUrl: './music-master.component.html',
  styleUrls: ['./music-master.component.css']
})
export class MusicMasterComponent implements OnInit {

  getmusic = [];
  getallalbums= [];
  addalbum=[];

  albumForm: FormGroup = this.formbuilder.group({
    AlbumName: ['', Validators.required],
    Year: ['', Validators.required],
    GenreId: ['', Validators.required]
  })

  constructor(private service: AuthService,private formbuilder: FormBuilder) {
   
    this.GetAllAlbum();
    this.addAlbums();
   }
     ngOnInit(): void {
  }
   addAlbums(){
    debugger;
    this.albumForm.value.Year=Number(this.albumForm.value.Year);
    this.albumForm.value.GenreId=Number(this.albumForm.value.GenreId);
      this.service.AddAlbums(this.albumForm.value).subscribe(resp => {
        debugger;
        this.GetAllAlbum();
         if (resp["status"] == 200) {
         alert(resp["data"]);
      }
      else {
        alert(resp["data"]);
      }
    })
  }
 
GetAllAlbum() {
 debugger;
  this.service.GetAllAlbums().subscribe(resp => {
   
    if (resp["status"] == 200) {
      console.log(resp["data"]);
      this.getallalbums = resp["data"];
    }
    else {
      alert(resp["data"]);
    }
  })
}
}

